export const headerData = [
    { title: "Link1", url: "#" },
    { title: "Link2", url: "#" }
];