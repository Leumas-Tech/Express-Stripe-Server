export const information2 = [
    { title: "Doc1", content: "Lorem ipsum doc1 content" },
    { title: "Doc2", content: "Lorem ipsum doc2 content" }
    //... add more docs
];